let emprecords = [
    {ename:"Parag",id:100,bsal:10000},
    {ename:"Prachi",id:101,bsal:13000},
    {ename:"Manas",id:200,bsal:9000},
    {ename:"Daesha",id:115,bsal:8000},
    {ename:"Anagha",id:104,bsal:20000}
  ];
  
  // 1. Calculate the total salary for the employees who has salary more than 9000
  let totalSalAbove9000 = emprecords
    .filter(e => e.bsal > 9000)
    .reduce((acc, emp) => acc + emp.bsal, 0);
  console.log("Total salary for employees with salary > 9000:", totalSalAbove9000);
  
  // 2. Find out the names of employees who has salary more than 8000
  let enamesAbove8000 = emprecords
    .filter(e => e.bsal > 8000)
    .map(e => e.ename);
  console.log("Employees with salary > 8000:", enamesAbove8000);
  
  // 3. Print the total salary of the employees whose salary >=9000 after adding bonus of 15% on basic sal
  let totalSalWithBonus = emprecords
    .filter(e => e.bsal >= 9000)
    .map(e => e.bsal * 1.15) // add 15% bonus
    .reduce((acc, sal) => acc + sal, 0);
  console.log("Total salary with bonus for employees with salary >= 9000:", totalSalWithBonus);